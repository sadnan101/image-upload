<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\StudentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/about', [HomeController::class, 'about'])->name('about');
Route::get('/product-detail/{id}', [HomeController::class, 'productDetail'])->name('product-detail');
Route::get('/contact', [HomeController::class, 'contact'])->name('contact');
Route::post('/full-name', [HomeController::class, 'makeFullName'])->name('full-name');
Route::get('/details/{id}', [HomeController::class, 'details'])->name('details');

Route::get('/student/add', [StudentController::class, 'index'])->name('student.add');
Route::post('/student/new', [StudentController::class, 'save'])->name('student.new');
Route::get('/student/manage', [StudentController::class, 'manage'])->name('student.manage');
Route::get('/student/edit/{id}', [StudentController::class, 'edit'])->name('student.edit');
