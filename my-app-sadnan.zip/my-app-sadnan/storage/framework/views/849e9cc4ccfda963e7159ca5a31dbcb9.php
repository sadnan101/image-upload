<h>dfsdfdsf</h>
<?php /**PATH C:\Users\Admin panel\Desktop\my-app\resources\views/basis.blade.php ENDPATH**/ ?>