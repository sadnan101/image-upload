<?php $__env->startSection('cr'); ?>
    details page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="py-5 bg-dark-subtle">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="card card-body">
                        <img src="<?php echo e(asset($blog['image'])); ?>" alt="">
                        <h4 class="py-2"><?php echo e($blog['title']); ?></h4>
                        <p><?php echo e($blog['description']); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\P. Digital Marketing\Desktop\my-app\resources\views/details.blade.php ENDPATH**/ ?>