<?php $__env->startSection('cr'); ?>
Hai
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="py-5 bg-danger-subtle">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="<?php echo e(asset($product['image'])); ?>" alt="" class=""/>
                        <div class="card-body">
                            <h4><?php echo e($product['name']); ?></h4>
                            <p>Tk. <?php echo e($product['price']); ?></p>
                            <hr/>
                            <a href="<?php echo e(route('product-detail', ['id' => $product['id']])); ?>" class="btn btn-success">Detail</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin panel\Desktop\my-app\resources\views/about.blade.php ENDPATH**/ ?>