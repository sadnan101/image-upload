<?php $__env->startSection('body'); ?>
<section class="bg-dark-subtle py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-7 mx-auto">
                <div class="card card-body">
                    <h4>Add Student Form</h4>
                    <hr/>
                    <form action="<?php echo e(route('student.new')); ?>" method="POST" >
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <label class="col-md-3">Student Name</label>
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="name"/>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-md-3">Student Email</label>
                            <div class="col-md-9">
                                <input type="email" class="form-control" name="email"/>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-md-3">Student Mobile</label>
                            <div class="col-md-9">
                                <input type="number" class="form-control" name="mobile"/>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-md-3">Student Address</label>
                            <div class="col-md-9">
                                <textarea class="form-control" name="address"></textarea>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-md-3">Gender Info</label>
                            <div class="col-md-9">
                                <label><input type="radio" checked value="Male" name="gender"/> Male</label>
                                <label><input type="radio" value="Female" name="gender"/> Female</label>
                                <label><input type="radio" value="Other" name="gender"/> Other</label>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-md-3"></label>
                            <div class="col-md-9">
                                <input type="submit" class="btn btn-success" value="Submit"/>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin panel\Desktop\my-app\resources\views/student/add.blade.php ENDPATH**/ ?>