<?php $__env->startSection('body'); ?>
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="card card-body">
                    <img src="<?php echo e(asset($product['image'])); ?>" alt=""/>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card card-body">
                    <h1><?php echo e($product['name']); ?></h1>
                    <h4>TK. <?php echo e($product['price']); ?></h4>
                    <p><?php echo e($product['description']); ?></p>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin panel\Desktop\my-app\resources\views/product-detail.blade.php ENDPATH**/ ?>