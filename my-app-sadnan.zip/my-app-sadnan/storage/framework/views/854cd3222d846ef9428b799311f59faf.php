<?php $__env->startSection('cr'); ?>
Hello
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="py-5 bg-dark-subtle">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card card-body" >
                        <img src="<?php echo e(asset($blog['image'])); ?>" alt="">
                        <h4 class="py-2"><?php echo e($blog['title']); ?></h4>
                        <p><?php echo e($blog['description']); ?></p>
                        <a href="<?php echo e(route('details',['id'=>$blog['id']])); ?>" class="btn btn-primary">read more</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


















            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\P. Digital Marketing\Desktop\my-app\resources\views/home.blade.php ENDPATH**/ ?>