
<h1>Hello BITM</h1>
<?php /**PATH C:\Users\Admin panel\Desktop\my-app\resources\views/bitm.blade.php ENDPATH**/ ?>