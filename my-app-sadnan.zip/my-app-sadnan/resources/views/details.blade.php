@extends('master')

@section('cr')
    details page
@endsection

@section('body')
    <section class="py-5 bg-dark-subtle">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="card card-body">
                        <img src="{{ asset($blog['image']) }}" alt="">
                        <h4 class="py-2">{{ $blog['title'] }}</h4>
                        <p>{{$blog['description']}}</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @endsection
