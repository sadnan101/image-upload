@extends('master')

@section('body')
    <section class="py-5 bg-dark-subtle">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-body">
                        <h4 class="text-success">All student Info</h4>
                        <hr/>
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>SL No</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>mobile</th>
                                <th>Address</th>
                                <th>gender</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($students as $student)
                                <tr>
                            <td>{{$loop->iteration}}</td>
                            <td>{{$student->name}}</td>
                            <td>{{$student->email}}</td>
                            <td>{{$student->mobile}}</td>
                            <td>{{$student->address}}</td>
                            <td>{{$student->gender}}</td>
                                    <td>
                                        <a href="{{route('student.edit',['id' => $student->id])}}" class="btn btn-success btn-sm">Edit</a>
                                        <a href="" class="btn btn-success btn-sm">delete</a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
