@extends('master')

@section('cr')
Hai
@endsection

@section('body')
    <section class="py-5 bg-danger-subtle">
        <div class="container">
            <div class="row">
                @foreach($products as $product)
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="{{asset($product['image'])}}" alt="" class=""/>
                        <div class="card-body">
                            <h4>{{$product['name']}}</h4>
                            <p>Tk. {{$product['price']}}</p>
                            <hr/>
                            <a href="{{route('product-detail', ['id' => $product['id']])}}" class="btn btn-success">Detail</a>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>
@endsection

