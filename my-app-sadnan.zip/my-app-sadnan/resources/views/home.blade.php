@extends('master')

@section('cr')
Hello
@endsection

@section('body')
    <section class="py-5 bg-dark-subtle">
        <div class="container">
            <div class="row">
                @foreach($blogs as $blog)
                <div class="col-md-4">
                    <div class="card card-body" >
                        <img src="{{ asset($blog['image']) }}" alt="">
                        <h4 class="py-2">{{ $blog['title'] }}</h4>
                        <p>{{ $blog['description'] }}</p>
                        <a href="{{ route('details',['id'=>$blog['id']]) }}" class="btn btn-primary">read more</a>
                    </div>
                </div>
                @endforeach

{{--                <div class="col-md-4">--}}
{{--                    <div class="card card-body">--}}
{{--                        <img src="{{ asset('img') }}/s1.jpg" alt="">--}}
{{--                        <h4 class="py-2">This is Home page</h4>--}}
{{--                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci amet aperiam atque, debitis dignissimos dolorem dolores esse et expedita nam nesciunt odit placeat quae repellat sed sequi, ut vero voluptatum?</p>--}}
{{--                        <a href="" class="btn btn-primary">read more</a>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--                <div class="col-md-4">--}}
{{--                    <div class="card card-body">--}}
{{--                        <img src="{{ asset('img') }}/s1.jpg" alt="">--}}
{{--                        <h4 class="py-2">This is Home page</h4>--}}
{{--                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci amet aperiam atque, debitis dignissimos dolorem dolores esse et expedita nam nesciunt odit placeat quae repellat sed sequi, ut vero voluptatum?</p>--}}
{{--                        <a href="" class="btn btn-primary">read more</a>--}}
{{--                    </div>--}}
{{--                </div>--}}

            </div>
        </div>
    </section>
@endsection
