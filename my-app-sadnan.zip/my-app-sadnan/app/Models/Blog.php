<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    use HasFactory;
    public static  function data(){
        return [
              0=> [
                    'id'          =>1,
                    'title'       =>'This is blog content 1',
                    'description' =>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci amet aperiam atque, debitis dignissimos dolorem dolores esse et expedita nam nesciunt odit placeat quae repellat sed sequi, ut vero voluptatum?',
                    'image'       =>'img/s1.jpg'
                ],
            1=> [
                'id'          =>2,
                'title'       =>'This is blog content 2',
                'description' =>' 214234 Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci amet aperiam atque, debitis dignissimos dolorem dolores esse et expedita nam nesciunt odit placeat quae repellat sed sequi, ut vero voluptatum?',
                'image'       =>'img/s2.jpg'
            ],
            2=> [
                'id'          =>3,
                'title'       =>'This is blog content 2',
                'description' =>'fdhgdf Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci amet aperiam atque, debitis dignissimos dolorem dolores esse et expedita nam nesciunt odit placeat quae repellat sed sequi, ut vero voluptatum?',
                'image'       =>'img/s2.jpg'
            ],
        ];
    }

}
