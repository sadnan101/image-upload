<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    private $products = [];

    public function __construct()
    {
        $this->products = [
            0 => [
                'id'            => 1,
                'name'          => 'Product One',
                'image'         => 'img/1.webp',
                'price'         => '2500',
                'description'   => 'This is product one description',
            ],
            1 => [
                'id'            => 2,
                'name'          => 'Product Two',
                'image'         => 'img/2.webp',
                'price'         => '1500',
                'description'   => 'This is product Two description',
            ],
            2 => [
                'id'            => 3,
                'name'          => 'Product Three',
                'image'         => 'img/3.webp',
                'price'         => '3500',
                'description'   => 'This is product Three description',
            ],
            3 => [
                'id'            => 4,
                'name'          => 'Product Four',
                'image'         => 'img/4.webp',
                'price'         => '5500',
                'description'   => 'This is product Four description',
            ],
        ];
    }

    public function getAllProduct()
    {
        return $this->products;
    }


    public function getProductById($id)
    {
        foreach ($this->products as $product)
        {
            if ($product['id'] == $id)
            {
                return $product;
            }
        }
    }
}
