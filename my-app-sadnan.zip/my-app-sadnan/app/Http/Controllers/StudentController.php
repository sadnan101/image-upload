<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use DB;

class StudentController extends Controller
{
    public $student ,$students;
    public function index()
    {
        return view('student.add');
    }
    public function save(Request $request){

        $this->student = new Student();
        $this->student->name    = $request->name;
        $this->student->email   = $request->email;
        $this->student->mobile  = $request->mobile;
        $this->student->address = $request->address;
        $this->student->gender  = $request->gender;
        $this->student->save();

       return back()->with('massage','Student info save successfully.');
    }
    public function manage()
    {
        $this->students = Student::all();
        return view('student.manage',['students => $this->students']);
    }
    public function edit($id)
    {
        $this->student = Student::find($id);
        return view('student.edit');
    }
}
