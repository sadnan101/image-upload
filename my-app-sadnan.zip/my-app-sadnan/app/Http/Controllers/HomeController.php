<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Http\Request;
use App\Models\Product;

class HomeController extends Controller
{
    public $blogs, $product, $products, $singleProduct, $fullName;
    public function index()
    {

        $this->blogs = Blog::data();
//        return  $this->blogs;
        return view('home',[
            'blogs'=>$this->blogs
        ]);
    }
    public function details($id){
        $this->blogs = Blog::data();
        foreach ($this->blogs as $blog ){
            if ($blog['id'] == $id){
                return view('details',[
                    'blog'=>$blog
                ]);
            }
        }
    }


    public function about()
    {
        $this->product  = new Product();
        $this->products = $this->product->getAllProduct();
        return view('about', ['products' => $this->products]);
    }

    public function productDetail($id)
    {
        $this->product = new Product();
        $this->singleProduct = $this->product->getProductById($id);
        return view('product-detail', ['product' => $this->singleProduct]);
    }


    public function contact()
    {
        return view('contact');
    }

    public function makeFullName(Request $request)
    {
        $this->fullName = $request->first_name.' '.$request->last_name;
        return back()->with('result', $this->fullName);
    }
}
